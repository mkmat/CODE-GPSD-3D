#! /usr/bin/perl

# (c) 16 nov 2023 mk@mat.ethz.ch

require "./hard-code-software-location.pl";

$message1 = "-----------------------------------------------\n";
$message2 = "Afterwards, start $0 again.\n$message1";
$pwd=`pwd`; chomp $pwd; 

# directories
#$instdir[$#instdir+1]   = "nlopt-2.7.1";    
#$instdir[$#instdir+1]   = "voro++-0.4.6"; 

foreach $ie (0 .. $#exe) { $e=$exe[$ie];
   $found_exe[$ie]=`which $e 2> /dev/null`; chomp $found_exe[$ie];
   if ($found_exe[$ie]) { 
      print "found: \$exe[$ie]\t= $e at $found_exe[$ie]\n";
   } else { 
      $found_exe[$ie]=`find ./ -name "$e" -executable -print | head -1`; chomp $found_exe[$ie]; 
      if ($found_exe[$ie]) {
         print "found: \$exe[$ie]\t= $e at $found_exe[$ie]\n";
      } else {
         print "$message1";
         print "not found: \$exe[$ie]\t= $e\n"; 
         print "install $e from find $exe_download[$ie] and/or find $e on your disk and add the full absolute directory name as \$exe[$ie] = .. to section (A) of $0\n"; 
         print "$message2"; exit;
      };
   };
};

foreach $il (0 .. $#lib) { $l=$lib[$il]; 
   $found_lib[$il] = `locate $l | head -1`; chomp $found_lib[$il];
   if (!$found_lib[$il]) { $found_lib[$il] = `find $pwd -name $l -print | head -1`; chomp $found_lib[$il]; };
   if ($found_lib[$il]) {
      print "found: \$lib[$il]\t= $l at $found_lib[$il]\n";
   } else {
      print "$message1";
      print "not found: \$lib[$il]\t= $l\n";
      print "install $l from $lib_download[$il] and/or find $l on your disk and add the full absolute directory name as \$lib[$il] = .. to section (B) of $0\n"; 
      print "$message2"; exit;
   };
};

# locate voro++ installation directory
foreach $il (0 .. $#lib) { $l=$lib[$il];
   if ($l =~ /libvoro\+\+.a/) { 
      if (-d "$build[$il]") {
         print "found: \$build[$il]\t= $build[$il]\n"; 
      } else {
         $build[$il] = $found_lib[$il]; $build[$il] =~ s/src\/libvoro\+\+.a//;  
         if (-d "$build[$il]") { 
            print "found: \$build[$il]\t= $build[$il]\n";
         } else {
            print "$message1";
            print "not found: $build[$il]\t= $build[$il]\n";
            print "Add the full absolute directory name of the voro++ installation directory as \$build[$il]=.. to section (C) of $0\n"; 
            print "$message2"; exit;
         };
      }; 
   };
};

# locate voro++.hh
foreach $il (0 .. $#lib) { $l=$lib[$il];
   if ($l =~ /libvoro\+\+.a/) {
      if (-d "$file[$il]") {
         print "found: \$file[$il] = $file[$il]\n";
      } else {
         $file[$il] = `find $build[$il] -name $file[il]  -print | head -1`; chomp $file[$il];
         if (-s "$file[$il]") {
            print "found: \$file[$il] = $file[$il]\n"; 
         } else {
            print "$message1";
            print "not found: \$file[$il] = $file[$il]\n"; 
            print "Add the full absolute file name of voro++.hh as \$file[$il] = .. to section (D) of $0\n"; 
            print "$message2"; exit;
         }; 
      };
   };
};

# locate nlopt build directory
foreach $il (0 .. $#lib) { $l=$lib[$il];
   if ($l =~ /libnlopt.so/) {
      if (-d "$build[$il]") {
         print "found: \$build[$il]\t= $build[$il]\n";
      } else {
         $build[$il] = $found_lib[$il]; $build[$il] =~ s/\/libnlopt.so//;
         if (-d "$build[$il]") {
            print "found: \$build[$il]\t= $build[$il]\n";
         } else {
            print "$message1";
            print "not found: $build[$il]\t= $build[$il]\n";
            print "Add the full absolute directory name of the voro++ installation directory as \$build[$il]=.. to section (C) of $0\n";
            print "$message2"; exit;
         };
      };
   };
};

# compiler options
if ($exe[0] eq "g++")      { $c_compiler_options = "-O3 -std=c++11"; };
if ($exe[1] eq "ifort")    { $f_compiler_options = "-O3 -fopenmp"; };
if ($exe[1] eq "gfortran") { $f_compiler_options = "-Ofast -ffree-line-length-none -fopenmp"; };

# now save the information
$OUT=<<EOF;
\$compiler_cpp = "$found_exe[0]";
\$compiler_f90 = "$found_exe[1]";
\$voro         = "$found_exe[2]";
\$libvoro      = "$found_lib[0]";
\$libnlopt     = "$found_lib[1]";
\$build_voro   = "$build[0]";
\$build_nlopt  = "$build[1]";
\$vorohh       = "$file[0]";
# compiler options (please review)
\$f_compiler_options = "$f_compiler_options";
\$c_compiler_options = "$c_compiler_options";
EOF

print $OUT;

open(INFO,">software-locations.txt");
print INFO $OUT; 
close(INFO);
print "created software-locations.txt\n";
print "Now call: perl ./INSTALL.pl\n";

